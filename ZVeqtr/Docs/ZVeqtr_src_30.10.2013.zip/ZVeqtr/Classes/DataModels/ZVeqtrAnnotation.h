//
//  ZVeqtrAnnotation.h
//  ZVeqtr
//
//  Created by Lee Loo on 11/4/12.
//  Copyright (c) 2012 PE-Leonid.Lo. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol ZVeqtrAnnotation <MKAnnotation, NSObject>
@property (nonatomic, assign) BOOL		wasUpdated;
@end
