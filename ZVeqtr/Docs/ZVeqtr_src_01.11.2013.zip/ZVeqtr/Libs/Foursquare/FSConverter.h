//
//  FSConverter.h
//  Foursquare2-iOS
//
//  Created by Constantine Fry on 2/7/13.
//
//

#import <Foundation/Foundation.h>

@interface FSConverter : NSObject
-(NSArray*)convertToObjects:(NSArray*)venues;
-(NSMutableArray*)convertToVenueObjects:(NSArray*)venues;
@end
