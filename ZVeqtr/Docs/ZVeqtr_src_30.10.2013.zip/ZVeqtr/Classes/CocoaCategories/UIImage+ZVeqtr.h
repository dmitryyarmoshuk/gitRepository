//
//  UIImage+ZVeqtr.h
//  ZVeqtr
//
//  Created by Leonid Lo on 10/15/12.
//  Copyright (c) 2012 PE-Leonid.Lo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (ZVeqtr)

- (UIImage *)scaleAndRotate;

@end
