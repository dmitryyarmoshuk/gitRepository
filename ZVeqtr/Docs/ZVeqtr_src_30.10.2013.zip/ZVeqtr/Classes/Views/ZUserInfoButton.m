//
//  ZUserInfoButton.m
//  ZVeqtr
//
//  Created by Maxim on 4/30/13.
//  Copyright (c) 2013 PE-Leonid.Lo. All rights reserved.
//

#import "ZUserInfoButton.h"

@implementation ZUserInfoButton

@end
