//
//  ZCopyableCell.h
//  ZVeqtr
//
//  Created by Maxim on 3/11/13.
//  Copyright (c) 2013 PE-Leonid.Lo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCopyableCell : UITableViewCell

@end
