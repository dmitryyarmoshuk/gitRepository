//
//  ZSellModuleAddImageViewController.h
//  ZVeqtr
//
//  Created by Maxim on 4/4/13.
//  Copyright (c) 2013 PE-Leonid.Lo. All rights reserved.
//

#import "ZSuperViewController.h"
#import "ZGarageSaleModel.h"


@interface ZSellModuleAddImageViewController : ZSuperViewController

@property (nonatomic, retain) ZGarageSaleModel *garageSaleModel;

@end
