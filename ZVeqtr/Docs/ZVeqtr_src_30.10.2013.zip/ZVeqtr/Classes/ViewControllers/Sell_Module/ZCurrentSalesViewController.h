//
//  ZCurrentSalesViewController.h
//  ZVeqtr
//
//  Created by Maxim on 4/17/13.
//  Copyright (c) 2013 PE-Leonid.Lo. All rights reserved.
//

#import "ZSuperViewController.h"

@interface ZCurrentSalesViewController : ZSuperViewController

@end
