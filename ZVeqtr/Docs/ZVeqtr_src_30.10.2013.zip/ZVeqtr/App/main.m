//
//  main.m
//  Peek
//
//  Created by Pavel on 08.07.11.
//  Copyright 2011 Horns & Hoofs. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
	int retVal;
    @autoreleasepool {
		retVal = UIApplicationMain(argc, argv, nil, @"PeekAppDelegate");
		
	}
    return retVal;
}