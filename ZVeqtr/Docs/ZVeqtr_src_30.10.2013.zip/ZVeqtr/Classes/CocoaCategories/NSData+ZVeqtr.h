//
//  NSData+ZVeqtr.h
//  ZVeqtr
//
//  Created by Leonid Lo on 10/17/12.
//  Copyright (c) 2012 PE-Leonid.Lo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (ZVeqtr)
- (NSString *)hexString;
@end
