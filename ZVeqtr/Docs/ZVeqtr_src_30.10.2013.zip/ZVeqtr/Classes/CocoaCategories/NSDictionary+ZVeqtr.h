//
//  NSDictionary+ZVeqtr.h
//  ZVeqtr
//
//  Created by Leonid Lo on 10/15/12.
//  Copyright (c) 2012 PE-Leonid.Lo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (ZVeqtr)
+ (NSDictionary *)dictionaryWithResponseString:(NSString *)string;
@end
