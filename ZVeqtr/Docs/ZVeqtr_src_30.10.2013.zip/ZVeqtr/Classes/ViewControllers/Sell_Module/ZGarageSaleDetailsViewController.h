//
//  ZGarageSaleDetailsViewController.h
//  ZVeqtr
//
//  Created by Maxim on 4/4/13.
//  Copyright (c) 2013 PE-Leonid.Lo. All rights reserved.
//

#import "ZBaseSaleDetailsViewController.h"

@interface ZGarageSaleDetailsViewController : ZBaseSaleDetailsViewController

@end
