//
//  ZDebug.m
//  ZVeqtr
//
//  Created by Leonid Lo on 11/9/12.
//  Copyright (c) 2012 PE-Leonid.Lo. All rights reserved.
//

#import "ZDebug.h"

@implementation NSNumber (DEBUG_)
- (int)length {
	LLog(@"");
	return 0;
}

- (BOOL)isEqualToString:(id)object {
	LLog(@"");
	return NO;
}
@end
