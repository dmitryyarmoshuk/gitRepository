//
//  ZGarageSaleRootViewController.h
//  ZVeqtr
//
//  Created by Maxim on 4/4/13.
//  Copyright (c) 2013 PE-Leonid.Lo. All rights reserved.
//

#import "ZSuperViewController.h"

@interface ZGarageSaleRootViewController : ZSuperViewController

@end
