//
//  ZSaleTemplateListViewController.h
//  ZVeqtr
//
//  Created by Maxim on 4/25/13.
//  Copyright (c) 2013 PE-Leonid.Lo. All rights reserved.
//

#import "ZSuperViewController.h"

@interface ZSaleTemplateListViewController : ZSuperViewController

@end
