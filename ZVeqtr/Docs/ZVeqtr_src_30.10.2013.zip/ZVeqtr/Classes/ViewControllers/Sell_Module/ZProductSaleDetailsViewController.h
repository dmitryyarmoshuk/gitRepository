//
//  ZProductSaleDetailsViewController.h
//  ZVeqtr
//
//  Created by Maxim on 4/7/13.
//  Copyright (c) 2013 PE-Leonid.Lo. All rights reserved.
//

#import "ZBaseSaleDetailsViewController.h"
#import "ZThumbnailPictureViewController.h"


@interface ZProductSaleDetailsViewController : ZBaseSaleDetailsViewController<ZThumbnailPictureViewControllerDelegate>

@end
