//
//  ZUserInfoButton.h
//  ZVeqtr
//
//  Created by Maxim on 4/30/13.
//  Copyright (c) 2013 PE-Leonid.Lo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZUserInfoButton : UIButton

@property (nonatomic, retain) id userInfo;

@end
